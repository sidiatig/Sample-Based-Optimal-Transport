# Sample-Based-Optimal-Transport
Tools for solving the sample based optimal transport problem. Requires Python (3.x preffered) and numpy,scipy
